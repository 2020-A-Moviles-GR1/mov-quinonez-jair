package com.example.moviles1

class RecyclerAdaptador (
    private val listaUsusarios: List<UsuarioHttp>,
            //private val contexto
private val recyclerView: RecyclerView
) : androidx
}