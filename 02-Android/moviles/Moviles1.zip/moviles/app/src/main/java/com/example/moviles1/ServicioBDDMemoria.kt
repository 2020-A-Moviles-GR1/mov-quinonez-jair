package com.example.moviles1

class ServicioBDDMemoria {
    companion object{
        var numero = 0
        fun anadir_numero(){
            this.numero = this.numero + 1
        }
    }
}